/****************************************************************************
** Meta object code from reading C++ file 'main_window.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.8)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "main_window.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'main_window.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.8. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[38];
    char stringdata0[472];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 11), // "viewUpdated"
QT_MOC_LITERAL(2, 23, 0), // ""
QT_MOC_LITERAL(3, 24, 5), // "about"
QT_MOC_LITERAL(4, 30, 17), // "printShortcutKeys"
QT_MOC_LITERAL(5, 48, 12), // "setQuitTimer"
QT_MOC_LITERAL(6, 61, 15), // "openGameLogFile"
QT_MOC_LITERAL(7, 77, 7), // "kickOff"
QT_MOC_LITERAL(8, 85, 14), // "connectMonitor"
QT_MOC_LITERAL(9, 100, 16), // "connectMonitorTo"
QT_MOC_LITERAL(10, 117, 17), // "disconnectMonitor"
QT_MOC_LITERAL(11, 135, 16), // "reconnectMonitor"
QT_MOC_LITERAL(12, 152, 13), // "toggleMenuBar"
QT_MOC_LITERAL(13, 166, 7), // "checked"
QT_MOC_LITERAL(14, 174, 13), // "toggleToolBar"
QT_MOC_LITERAL(15, 188, 15), // "toggleStatusBar"
QT_MOC_LITERAL(16, 204, 16), // "toggleFullScreen"
QT_MOC_LITERAL(17, 221, 20), // "showPlayerTypeDialog"
QT_MOC_LITERAL(18, 242, 11), // "changeStyle"
QT_MOC_LITERAL(19, 254, 16), // "showConfigDialog"
QT_MOC_LITERAL(20, 271, 13), // "setFocusPoint"
QT_MOC_LITERAL(21, 285, 5), // "point"
QT_MOC_LITERAL(22, 291, 8), // "dropBall"
QT_MOC_LITERAL(23, 300, 3), // "pos"
QT_MOC_LITERAL(24, 304, 12), // "freeKickLeft"
QT_MOC_LITERAL(25, 317, 13), // "freeKickRight"
QT_MOC_LITERAL(26, 331, 10), // "yellowCard"
QT_MOC_LITERAL(27, 342, 4), // "side"
QT_MOC_LITERAL(28, 347, 4), // "unum"
QT_MOC_LITERAL(29, 352, 7), // "redCard"
QT_MOC_LITERAL(30, 360, 14), // "changePlayMode"
QT_MOC_LITERAL(31, 375, 4), // "mode"
QT_MOC_LITERAL(32, 380, 20), // "receiveMonitorPacket"
QT_MOC_LITERAL(33, 401, 12), // "resizeCanvas"
QT_MOC_LITERAL(34, 414, 4), // "size"
QT_MOC_LITERAL(35, 419, 19), // "updatePositionLabel"
QT_MOC_LITERAL(36, 439, 11), // "setLiveMode"
QT_MOC_LITERAL(37, 451, 20) // "togglePlayOrStopIcon"

    },
    "MainWindow\0viewUpdated\0\0about\0"
    "printShortcutKeys\0setQuitTimer\0"
    "openGameLogFile\0kickOff\0connectMonitor\0"
    "connectMonitorTo\0disconnectMonitor\0"
    "reconnectMonitor\0toggleMenuBar\0checked\0"
    "toggleToolBar\0toggleStatusBar\0"
    "toggleFullScreen\0showPlayerTypeDialog\0"
    "changeStyle\0showConfigDialog\0setFocusPoint\0"
    "point\0dropBall\0pos\0freeKickLeft\0"
    "freeKickRight\0yellowCard\0side\0unum\0"
    "redCard\0changePlayMode\0mode\0"
    "receiveMonitorPacket\0resizeCanvas\0"
    "size\0updatePositionLabel\0setLiveMode\0"
    "togglePlayOrStopIcon"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      32,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,  174,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       3,    0,  175,    2, 0x08 /* Private */,
       4,    0,  176,    2, 0x08 /* Private */,
       5,    0,  177,    2, 0x08 /* Private */,
       6,    0,  178,    2, 0x08 /* Private */,
       7,    0,  179,    2, 0x08 /* Private */,
       8,    0,  180,    2, 0x08 /* Private */,
       9,    0,  181,    2, 0x08 /* Private */,
      10,    0,  182,    2, 0x08 /* Private */,
      11,    0,  183,    2, 0x08 /* Private */,
      12,    1,  184,    2, 0x08 /* Private */,
      14,    1,  187,    2, 0x08 /* Private */,
      15,    1,  190,    2, 0x08 /* Private */,
      16,    0,  193,    2, 0x08 /* Private */,
      17,    0,  194,    2, 0x08 /* Private */,
      18,    1,  195,    2, 0x08 /* Private */,
      19,    0,  198,    2, 0x08 /* Private */,
      20,    1,  199,    2, 0x08 /* Private */,
      22,    1,  202,    2, 0x08 /* Private */,
      24,    1,  205,    2, 0x08 /* Private */,
      25,    1,  208,    2, 0x08 /* Private */,
      26,    2,  211,    2, 0x08 /* Private */,
      29,    2,  216,    2, 0x08 /* Private */,
      26,    0,  221,    2, 0x08 /* Private */,
      29,    0,  222,    2, 0x08 /* Private */,
      30,    1,  223,    2, 0x08 /* Private */,
      30,    2,  226,    2, 0x08 /* Private */,
      32,    0,  231,    2, 0x08 /* Private */,
      33,    1,  232,    2, 0x08 /* Private */,
      35,    1,  235,    2, 0x08 /* Private */,
      36,    0,  238,    2, 0x08 /* Private */,
      37,    1,  239,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   13,
    QMetaType::Void, QMetaType::Bool,   13,
    QMetaType::Void, QMetaType::Bool,   13,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   13,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QPoint,   21,
    QMetaType::Void, QMetaType::QPoint,   23,
    QMetaType::Void, QMetaType::QPoint,   23,
    QMetaType::Void, QMetaType::QPoint,   23,
    QMetaType::Void, QMetaType::Char, QMetaType::Int,   27,   28,
    QMetaType::Void, QMetaType::Char, QMetaType::Int,   27,   28,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   31,
    QMetaType::Void, QMetaType::Int, QMetaType::QPoint,   31,   21,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QSize,   34,
    QMetaType::Void, QMetaType::QPoint,   21,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   13,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->viewUpdated(); break;
        case 1: _t->about(); break;
        case 2: _t->printShortcutKeys(); break;
        case 3: _t->setQuitTimer(); break;
        case 4: _t->openGameLogFile(); break;
        case 5: _t->kickOff(); break;
        case 6: _t->connectMonitor(); break;
        case 7: _t->connectMonitorTo(); break;
        case 8: _t->disconnectMonitor(); break;
        case 9: _t->reconnectMonitor(); break;
        case 10: _t->toggleMenuBar((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 11: _t->toggleToolBar((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 12: _t->toggleStatusBar((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 13: _t->toggleFullScreen(); break;
        case 14: _t->showPlayerTypeDialog(); break;
        case 15: _t->changeStyle((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 16: _t->showConfigDialog(); break;
        case 17: _t->setFocusPoint((*reinterpret_cast< const QPoint(*)>(_a[1]))); break;
        case 18: _t->dropBall((*reinterpret_cast< const QPoint(*)>(_a[1]))); break;
        case 19: _t->freeKickLeft((*reinterpret_cast< const QPoint(*)>(_a[1]))); break;
        case 20: _t->freeKickRight((*reinterpret_cast< const QPoint(*)>(_a[1]))); break;
        case 21: _t->yellowCard((*reinterpret_cast< const char(*)>(_a[1])),(*reinterpret_cast< const int(*)>(_a[2]))); break;
        case 22: _t->redCard((*reinterpret_cast< const char(*)>(_a[1])),(*reinterpret_cast< const int(*)>(_a[2]))); break;
        case 23: _t->yellowCard(); break;
        case 24: _t->redCard(); break;
        case 25: _t->changePlayMode((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 26: _t->changePlayMode((*reinterpret_cast< const int(*)>(_a[1])),(*reinterpret_cast< const QPoint(*)>(_a[2]))); break;
        case 27: _t->receiveMonitorPacket(); break;
        case 28: _t->resizeCanvas((*reinterpret_cast< const QSize(*)>(_a[1]))); break;
        case 29: _t->updatePositionLabel((*reinterpret_cast< const QPoint(*)>(_a[1]))); break;
        case 30: _t->setLiveMode(); break;
        case 31: _t->togglePlayOrStopIcon((*reinterpret_cast< bool(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (MainWindow::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::viewUpdated)) {
                *result = 0;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject MainWindow::staticMetaObject = { {
    &QMainWindow::staticMetaObject,
    qt_meta_stringdata_MainWindow.data,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 32)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 32;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 32)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 32;
    }
    return _id;
}

// SIGNAL 0
void MainWindow::viewUpdated()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
