# StarterAgent2D
Robocup Agent2D For Student's League.

First release in [HERE](https://github.com/naderzare/StarterAgent2D) by [Nader Zare](https://github.com/naderzare).

## Run Team

```
cd src && ./start.sh -t teamname
```

