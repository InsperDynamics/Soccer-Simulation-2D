#!/bin/bash
set -e
cd ./Agent
make -j8




